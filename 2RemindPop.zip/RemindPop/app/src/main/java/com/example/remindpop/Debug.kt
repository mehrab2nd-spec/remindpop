package com.example.remindpop

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Debug {
    fun log(ctx: Context, text: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val p = ctx.getSharedPreferences("dbg", Context.MODE_PRIVATE)
        val old = p.getString("log", "") ?: ""
        val lines = (listOf("$t  $text") + old.lines().filter { it.isNotBlank() }).take(6)
        p.edit().putString("log", lines.joinToString("\n")).apply()
    }
    fun read(ctx: Context): String =
        ctx.getSharedPreferences("dbg", Context.MODE_PRIVATE).getString("log", "") ?: ""
}
