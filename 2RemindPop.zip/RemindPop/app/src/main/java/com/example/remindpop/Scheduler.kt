package com.example.remindpop

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Scheduler {
    fun schedule(ctx: Context, delayMs: Long, message: String) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val fire = PendingIntent.getBroadcast(
            ctx, id,
            Intent(ctx, AlarmReceiver::class.java).putExtra("msg", message),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        // setAlarmClock: exact, works in Doze, needs no extra permission
        am.setAlarmClock(AlarmManager.AlarmClockInfo(System.currentTimeMillis() + delayMs, show), fire)
    }
}
