package com.example.remindpop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val msg = intent.getStringExtra("msg") ?: "কি করস?"
        Debug.log(context, "অ্যালার্ম এসেছে")
        try {
            context.startForegroundService(
                Intent(context, OverlayService::class.java).putExtra("msg", msg)
            )
        } catch (e: Exception) {
            Debug.log(context, "সার্ভিস চালু ব্যর্থ: ${e.javaClass.simpleName}")
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("alert", "Reminder alerts", NotificationManager.IMPORTANCE_HIGH))
            nm.notify(77, Notification.Builder(context, "alert")
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(msg).setAutoCancel(true).build())
        }
    }
}
