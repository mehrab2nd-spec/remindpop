# RemindPop
1. Android Studio (Koala বা নতুন) দিয়ে এই ফোল্ডার Open করো, Gradle Sync শেষ হতে দাও।
2. ফোন USB/ওয়্যারলেস দিয়ে যুক্ত করে Run চাপো (বা Build > Build APK).
3. অ্যাপ খুলে "অনুমতি দিন" চেপে "Display over other apps" অন করো।
4. Xiaomi/Oppo/Vivo/Samsung এ: অ্যাপ সেটিংসে Battery = Unrestricted, Autostart = অন করো।
