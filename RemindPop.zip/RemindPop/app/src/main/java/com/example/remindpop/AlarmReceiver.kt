package com.example.remindpop

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val msg = intent.getStringExtra("msg") ?: "কি করস?"
        context.startForegroundService(
            Intent(context, OverlayService::class.java).putExtra("msg", msg)
        )
    }
}
