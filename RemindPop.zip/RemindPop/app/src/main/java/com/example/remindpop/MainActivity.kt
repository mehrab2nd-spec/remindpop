package com.example.remindpop

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var etMessage: EditText
    private lateinit var etMinutes: EditText
    private lateinit var permCard: View
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        etMessage = findViewById(R.id.etMessage)
        etMinutes = findViewById(R.id.etMinutes)
        permCard = findViewById(R.id.permCard)
        tvStatus = findViewById(R.id.tvStatus)

        listOf(R.id.p2 to 2, R.id.p5 to 5, R.id.p10 to 10, R.id.p30 to 30).forEach { (id, m) ->
            findViewById<View>(id).setOnClickListener { etMinutes.setText(m.toString()) }
        }
        findViewById<View>(R.id.btnPerm).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        findViewById<View>(R.id.btnSave).setOnClickListener { save() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        permCard.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
    }

    private fun save() {
        val mins = etMinutes.text.toString().toLongOrNull()
        if (mins == null || mins <= 0) {
            Toast.makeText(this, "কত মিনিট পরে মনে করাবে সেটা দিন", Toast.LENGTH_SHORT).show()
            return
        }
        val msg = etMessage.text.toString().trim().ifEmpty { "কি করস?" }
        Scheduler.schedule(this, mins * 60_000, msg)
        tvStatus.text = "✓ $mins মিনিট পরে মনে করানো হবে"
        etMessage.setText("")
    }
}
