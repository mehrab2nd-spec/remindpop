package com.example.remindpop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.TextView

class OverlayService : Service() {
    private val views = mutableListOf<View>()
    private lateinit var wm: WindowManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        val msg = intent?.getStringExtra("msg") ?: "কি করস?"
        if (Settings.canDrawOverlays(this)) showPopup(msg) else {
            fallbackNotification(msg)
            if (views.isEmpty()) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun channel(id: String, name: String, importance: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(id, name, importance))
    }

    private fun startFg() {
        channel("fg", "Reminder", NotificationManager.IMPORTANCE_LOW)
        val n = Notification.Builder(this, "fg")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("রিমাইন্ডার")
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun fallbackNotification(msg: String) {
        channel("alert", "Reminder alerts", NotificationManager.IMPORTANCE_HIGH)
        val n = Notification.Builder(this, "alert")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(msg)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java)
            .notify((System.currentTimeMillis() % 100000).toInt() + 10, n)
    }

    private fun showPopup(msg: String) {
        val root = LayoutInflater.from(ContextThemeWrapper(this, R.style.AppTheme))
            .inflate(R.layout.overlay_popup, null)
        val card = root.findViewById<View>(R.id.card)
        root.findViewById<TextView>(R.id.tvMessage).text = msg
        root.setOnClickListener { dismiss(root) }          // বাইরে ট্যাপ
        card.setOnClickListener { }                        // কার্ডে ট্যাপ করলে বন্ধ হবে না
        root.findViewById<View>(R.id.btnClose).setOnClickListener { dismiss(root) }
        root.findViewById<View>(R.id.btnSnooze).setOnClickListener {
            Scheduler.schedule(this, 5 * 60_000L, msg)
            dismiss(root)
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        )
        lp.dimAmount = 0.25f
        if (Build.VERSION.SDK_INT >= 31) {          // Android 12+ এ আসল গ্লাস ব্লার
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 40
        }

        card.alpha = 0f; card.scaleX = 0.9f; card.scaleY = 0.9f; card.translationY = -40f
        wm.addView(root, lp)
        views.add(root)
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(280).setInterpolator(DecelerateInterpolator()).start()

        getSystemService(Vibrator::class.java)
            ?.vibrate(VibrationEffect.createOneShot(180, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun dismiss(v: View) {
        if (!views.contains(v)) return
        views.remove(v)
        v.findViewById<View>(R.id.card).animate().alpha(0f).scaleX(0.92f).scaleY(0.92f)
            .setDuration(180).withEndAction {
                try { wm.removeView(v) } catch (_: Exception) {}
                if (views.isEmpty()) stopSelf()
            }.start()
    }

    override fun onDestroy() {
        views.forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        views.clear()
        super.onDestroy()
    }
}
